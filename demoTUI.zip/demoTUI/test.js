/**
 * Created by u on 2018/1/23.
 */
function test(){
    var obj = document.createElement("div");
    obj.style.width = 200;
    obj.style.height = 100;
    obj.innerHTML = "wahaha";
    var container = Monitor.addInContainer(obj, "p1");

    var obj1 = document.createElement("div");
    obj1.style.width = 500;
    obj1.style.height = 400;
    obj1.innerHTML = "1234213";
    var container1 = Monitor.addInContainer(obj1, "p1");

    //布局角色编辑
    var target = document.getElementsByTagName("body");
    target = target[0];

    var b1 = document.createElement("div");
    b1.style.cssText = "width:100%;height:100%";

    var c1 = document.createElement("lefter");
    c1.style.cssText = "width:50%;height:100%;float:left";
    c1.style.backgroundColor = "#cccccc";
    var c2 = document.createElement("righter");
    c2.style.cssText = "width:50%;height:100%;float:left";
    b1.appendChild(c1);
    b1.appendChild(c2);
    //
    c1.appendChild(container.mesh);
    c2.appendChild(container1.mesh);
    var containerb1 = Monitor.addInContainer(b1, "p1");
    target.appendChild(containerb1.mesh);

    setTimeout(function(e) {
        containerb1.mesh.style.display = "none";
    },2000);
    setTimeout(function(e) {
        containerb1.mesh.style.display = "block";
    },4000);
    setTimeout(function(e){
        T3.dispatchEvent(Monitor.Event.Active, container.mesh, {active:Monitor.Event.MessageShow});
        c2.style.display = "none";
    },5000);
}
test();


/*
** home page
**
*/

<style>
    //调用外部样式文件
    <link.....>
</style>
<script>
    //调用外部脚本文件
    <link...>
</script>
<temp>
    // 页面布局静态代码
    <table id="home_leader">
        <tr><td>hell0</td></tr>
        <tr>
            <td>th1</td>
            <td>th2</td>
        </tr>
    </table>
</temp>
<code>
    code = function() {
        this.updata = function() {};
        this.default = function() {};
        var createMode = function() {
        //......
        };
        createMode();
    };
</code>