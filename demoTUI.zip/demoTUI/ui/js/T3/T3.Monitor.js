/*
 * Monitor For tui JavaScript Library (流程框架 )
 * @Author tuxiaohua.TangDi / tu_xh@tangdi.net 屠晓华
 * @Copyright 2018 tui.Tu
 * @Tel: 13671816533
 * Date: 20180119
 * @update: v1.0.0 2018-03-06 页面加载配置解析 (L163)
 * @update: v1.0.1 2018-03-06 页面跳转统筹 (L262)
*/
var self = this;
var Monitor = {
    pageShowId: null,
    tagId:  "TUI_Monitor",
    Event:  {
        Active:      "Monitor_InContainer_Active",
        PageShow:   "Monitor_InContainer_Page_Show",
        PageHide:   "Monitor_InContainer_Page_Hide",
        MessageShow:   "Monitor_InContainer_Message_Show",
        MessageHide:   "Monitor_InContainer_Message_Hide",
        PageJump:   "Monitor_Page_Jump",
        PageEvent:  "Monitor_Page_Event"
    },
    /**
     * 数据池: 子容器统管
     */
    InContainerArr: [],
    /**
     * 内部:  子容器_对象
     * [参数]
     * child 控件
     * [案例]
     * var child = document.createElement("div");
     * var inContainer = new Monitor.InContainer(child);
     * [提取]
     * this.mesh 容器 | this.update 更新
     * this.data 数据 | this.pageNo 所属页面编号
     */
    InContainer:    function(child){
        this.data = null;
        this.pageNo = null;

        var contain = document.createElement("div");
        contain.style.cssText = "width:100%;height:100%;position:relative;top:0px;left:0px;";
        var body = document.createElement("intance");
        body.style.cssText = "width:100%;height:100%";
        var message = document.createElement("section");
        message.style.cssText = "width:100%;height:100%;position:absolute;top:0px;left:0px;display:none";
        message.style.backgroundColor = "rgba(0,0,0,0.5);";

        body.appendChild(child);
        contain.appendChild(body);
        contain.appendChild(message);

        //更新子控件数据
        this.update = function(param){
            this.data = param;
            if( typeof child["update"] == "function"){
                child.update(param);
            }
        };

        //页面初始化
        this.default = function(){
            if( typeof child["default"] == "function") {
                child.default();
            }
        };

        //清理数据 | 页面初始化
        this.clear = function(){
            this.data = null;
            this.default();
        };

        //this.dispatchEvent = function(event){
        //    var eventType = event.type;
        //    if( Monitor.Event.hide == eventType){
        //        this.mesh.style.display = "none";
        //    }else if( Monitor.Event.show == eventType){
        //        this.mesh.style.display = "";
        //    }
        //};

        /**
         * event.type           监听类型
         * event.data.active    事件分类名称
         * @param event
         */
        var onMessageEvent = function(event){
            if(event.data == null){
                return;
            }
            //debugger;
            var eventType = event.data.active;
            if( Monitor.Event.MessageHide == eventType){
                message.style.display = "none";
            }else if( Monitor.Event.MessageShow == eventType){
                message.style.display = "block";
            }else if( Monitor.Event.PageHide == eventType){
                this.mesh.style.display = "none";
            }else if( Monitor.Event.PageShow == eventType){
                this.mesh.style.display = "block";
            }
        };
        contain.addEventListener(Monitor.Event.Active, onMessageEvent);

        this.child = child;
        this.mesh = contain;
    },
    /**
     * 公共函数_增加: 控件子容器_统管
     * [参数]
     * child 控件
     * [案例]
     * var obj = document.createElement("div");
     * var container = Monitor.addInContainer(obj);
     */
    addInContainer: function(child, pageNo) {
        var inContainer = new Monitor.InContainer(child);
        inContainer.pageNo = pageNo;
        Monitor.InContainerArr._push(inContainer);
        return inContainer;
    },
    /**
     * 公共函数_删除: 控件子容器_统管
     * [参数]
     * child 控件
     * [案例]
     * var obj = document.createElement("div");
     * var container = Monitor.delInContainer(obj);
     */
    delInContainer: function(inContainer) {
        var index = Monitor.InContainerArr.indexof(inContainer);
        if(index >= 0){
            Monitor.InContainerArr.splice(index, 1);
        }
        return index;
    },
    /**
     * 外部脚本文件管理库
     */
    loadScriptArr: [],
    /**
     * 外部脚本文件执行函数 入库管理
     * @param url 外部脚本文件路径
     */
    loadScript: function(url){
        if(this.loadScriptArr.indexOf(url)<0){
            this.loadScriptArr.push(url);
            $.getScript(url);
        }
    }

};

/**
 * 类似:  Array.push()
 * 内部:  可以统一监控
 * @param param
 * @private
 */
Array.prototype._push = function(param) {
    if (param != null) {
        this.push(param);
    }
};

/**
 * 内部:  页面初始化_监听
 */
window.addEventListener("load", onSystemLoading, false);

/**
 * 内部:  页面初始化_处理
 */
function onSystemLoading(){
    tui.loadPage("http://127.0.0.1:9999/t3/updata/systemloading.xml", onSystemLoaded);
}
/**
 * 内部:  页面初始化_处理
 */
function onSystemLoaded(e){
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(e.responseText, "text/xml");
    //获取文档中标签元素对象
    var pages = xmlDoc.getElementsByTagName('page');
    var page, url, id, title;
    for(var i=0;i<pages.length; i++){
        page = pages[i];
        if(page == null){
            continue;
        }

        title = page.getAttribute("title");
        id = page.getAttribute("id");
        url = page.getAttribute("url");

        if(name != null && id != null && url != null){
            tui.addLoadList({name: title, id: id, url: url});
        }
    }
    this.addEventListener(tui.progressEvent.COMPLETEALL, function () {
        //监听加载完成事件
        console.log("监听加载完成事件");
        tui.dispatchEvent(Monitor.Event.PageJump, self, "home");
    });
    //创建加载控件
    tui.createLoad();

    //开始加载
    tui.loadBegin();

    self.addEventListener(Monitor.Event.PageJump, onPageJump);

    deFault();
}

/**
 * 公共接口_重构: 页面初始化
 */
function deFault(){}

/**
 * 解析界面跳转
 * @param event
 */
function onPageJump(event){
    debugger;
    var area;
    area = this[Monitor.tagId+event.data];
    area.style.display = "block";
    if(Monitor.pageShowId != null){
        area = this[Monitor.tagId+Monitor.pageShowId];
        area.style.display = "none";
    }
    Monitor.pageShowId = event.data;
}

self.addEventListener(tui.progressEvent.COMPLETE, function (e) {
    if(e["data"]){
        var mapData = e["data"];
        if(mapData["type"] == "tui"){
            requestTuiDoc(mapData["id"]);
        }
        mapData = null;
    }
});

/**
 * 解析tui文档格式
 * @param paramId
 */
function requestTuiDoc(paramId){
    var xmlHome = tui.loaddata[paramId];
    if(xmlHome) {
        //var dd = xmlHome.data;
        //var pager = $(xmlHome);
        //var txter = pager.text;
        //var datar = pager.data;
        //var innerTexter = pager.innerText;
        //var innerhtmler = pager.innerHTML;
        //var htmer = pager.html();
        debugger;
        var scripts = xmlHome.getElementsByTagName('scripts');
        var css = xmlHome.getElementsByTagName('css');
        var temp = xmlHome.getElementsByTagName('temp');
        var code = xmlHome.getElementsByTagName('code');
        if(scripts["data"]){
            var jsNode = scripts["data"].nodeValue;
            jsNode = jsNode.getElementsByTagName('script');
            debugger;
            if(jsNode) {
                if (jsNode["data"].length > 1) {
                    for (var i = 0; i < jsNode["data"].length; i++) {
                        Monitor.loadScript(jsNode["data"][i].nodeValue);
                    }
                } else {
                    Monitor.loadScript(jsNode["data"].nodeValue);
                }
            }
            jsNode = null;
            i = null;
        }
        if(css["data"]){
            document.head.innerHTML += css["data"].nodeValue;
            //document.write(css["data"].nodeValue);
        }
        if (temp["data"]) {
            var bodyer = document.getElementsByTagName("body");
            bodyer = bodyer[0];
            debugger;
            bodyer.innerHTML += "<div id='"+Monitor.tagId+temp["data"]["tag"].getAttribute("id")+"' class='tuiPage'>"+temp["data"].nodeValue+"</div>"; //('<sc'+'ript type="text/javascript" >'+ xmlHome+'</sc' + 'ript>');
        }
        if (code["data"]) {
            window.eval(code["data"].nodeValue);
        }
    }
}
/*
if (!Object.prototype.watch)
{
    debugger;
    Object.prototype.listener = function(prop, handler){
        debugger;
        this[prop] = handler;
        this["event"] = prop;
    };
    Object.prototype.dispatch = function(prop){
        debugger;
        var dd = this[prop];
        var ee = this[dd];
    };
    Object.prototype.watch = function(param){
        debugger;
        this.__defineSetter__(param);
        return this.dispatch("change");
    };
}
var div = document.getElementsByTagName("div")[0];
var dd = div.getAttribute("tance");
*/