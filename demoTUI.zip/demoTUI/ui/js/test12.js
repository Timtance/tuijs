/**
 * Created by u on 2018/1/23.
 */
 function test12(){
	alert("tests2022222");
 }